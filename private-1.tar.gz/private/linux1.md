# /proc

## /proc/stat

**proc/stat节点记录的是系统进程整体的统计信息**

### cpu时间

![image-20220915104830323](linux.assets/image-20220915104830323.png)

iowait时间是不可靠值，理由如下：

- CPU不会等待I/O执行完成，而iowait是等待I/O完成的时间。 当CPU进入idle状态，很可能会调度另一个task执行，所以iowait计算时间偏小；
- 多核CPU，iowait的计算并非某一个核，因此计算每一个cpu的iowait非常困难；

![image-20220915105531014](linux.assets/image-20220915105531014.png)

```
1 jiffies = 0.01s = 10ms
```

### stat数据

![image-20220915104930935](linux.assets/image-20220915104930935.png)

### 其余说明

1. intr：系统启动以来的所有interrupts的次数情况
2. ctxt: 系统上下文切换次数
3. btime：启动时长(单位:秒)，从Epoch(即1970零时)开始到系统启动所经过的时长，每次启动会改变。
   - 此处指为1500827856，转换北京时间为2017/7/24 0:37:36
4. `processes`：系统启动后所创建过的进程数量。当短时间该值特别大，系统可能出现异常
5. procs_running：处于Runnable状态的进程个数
6. procs_blocked：处于等待I/O完成的进程个数