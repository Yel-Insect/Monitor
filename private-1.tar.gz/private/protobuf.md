# protobuf

## 网站文档

https://protobuf.dev/getting-started/cpptutorial/

https://www.tutorialspoint.com/protobuf/protobuf_quick_guide.htm

## 枚举

```protobuf
syntax = "proto3";
package theater;
option java_package = "com.tutorialspoint.theater";
      
message Theater {
   enum PAYMENT_SYSTEM{
      CASH = 0;
      CREDIT_CARD = 1;
      DEBIT_CARD = 2;
      APP = 3;  
   }
   PAYMENT_SYSTEM payment = 7;
}
```

```java
package com.tutorialspoint.theater;

import java.io.FileOutputStream;
import java.io.IOException;
import com.tutorialspoint.theater.TheaterOuterClass.Theater;
import com.tutorialspoint.theater.TheaterOuterClass.Theater.PAYMENT_SYSTEM;

public class TheaterWriter{
   public static void main(String[] args) throws IOException {
       //设置枚举值
      Theater theater = Theater.newBuilder()
         .setPayment(PAYMENT_SYSTEM.CREDIT_CARD)
         .build();
		
      String filename = "theater_protobuf_output";
      System.out.println("Saving theater information to file: " + filename);
		
      try(FileOutputStream output = new FileOutputStream(filename)){
         theater.writeTo(output);
      }
	    
      System.out.println("Saved theater information with following data to disk: \n" + theater);
   }
}
```

## List/Repeated

## Any类型

  protobuf中的Any类型与C++中的泛型概念类似，可以定义为任意的类型。在序列化的时候可以通过PackFrom()方法将任意的数据类型打包为Any类型，反序列化的时候通过UnpackTo()把Any类型还原为原始类型。

```protobuf
// 要使用Any类型必须导入该proto文件
import "google/protobuf/any.proto";

message ErrorStatus {
  string message = 1;
  repeated google.protobuf.Any details = 2;
}
```

```c++
// Storing an arbitrary message type in Any.
NetworkErrorDetails details = ...;
ErrorStatus status;
status.add_details()->PackFrom(details);

// Reading an arbitrary message from Any.
ErrorStatus status = ...;
for (const Any& detail : status.details()) {
  if (detail.Is<NetworkErrorDetails>()) {
    NetworkErrorDetails network_error;
    detail.UnpackTo(&network_error);
    ... processing network_error ...
  }
}
```



## Oneof

- 如果有一条包含许多字段的消息，并且最多同时设置一个字段，您可以使用其中oneof功能来强制执行此行为并节省内存。

- Oneof 字段类似于常规字段，除了Oneof共享内存的所有字段之外，最多可以同时设置一个字段。
- 设置Oneof 的任何成员都会自动清除所有其他成员。您可以使用case()或WhichOneof()方法检查Oneof 中的哪个值被设置(如果有的话)，具体取决于选择的语言。
- 添加任何类型的字段，但不能使用重复字段。
- **如果您正在使用c++，请确保代码不会导致内存崩溃**。下面的示例代码将导致内存崩溃，因为它通过set_name()方法调用了已经删除掉的sub_message

```protobuf
message SampleMessage {
oneof test_oneof {
string name = 4;
SubMessage sub_message = 9;
}
}
```

```protobuf
设置oneof字段将自动清除oneof字段的所有其他成员。如果设置了几个oneof字段，则只有最后一个字段仍然有值。
例1：
SampleMessage message;
message.set_name("name");
CHECK(message.has_name());
message.mutable_sub_message();   // Will clear name field.
CHECK(!message.has_name());

例2：
SampleMessage message;
SubMessage* sub_message = message.mutable_sub_message();
message.set_name("name");      // Will delete sub_message
sub_message->set_...            // Crashes here
```



## Map

- map不能设置为repeated

- map的遍历是无序的

- 为proto生成文本格式时，map按key排序。数字key按数字排序。

- 从线上解析或合并时，如果有重复的map键，则使用最后的键。从文本格式解析map时，如果存在重复的键，解析可能会失败。

- 如果为映射字段提供了键但没有值，则序列化该字段时的行为取决于语言。在c++、Java和Python中，序列化该类型的默认值，而在其他语言中，不进行序列化

```protobuf
message WorkflowApplication{
    bytes identity = 1;
    string title = 2;
     // 参数列表
    map<string,ParameterType> arguments = 3;
     // 变量
    map<string,ParameterType> variables = 4;
     // 应用执行的组件
    optional Activity activity = 5;
}
```

```c++
方法1：
auto valMap = WorkflowApp.mutable_variables();
map[key] = value;

方法2：
auto map = WorkflowApp.mutable_variables();
(*map)[key] = value;

方法3：
std::unique_ptr<ProtoName> my_enclosing_proto(new ProtoName);
(*my_enclosing_proto->mutable_weight())[my_key] = my_value;

方法4：
 TestStruct tSt1;
tSt1.mutable_data()->insert({ 1, "str1" });
tSt1.mutable_data()->insert({ 1, "str11" });
tSt1.mutable_data()->insert(MapPair<int32_t, std::string>(2, "str2"));
std::string data;
tSt1.SerializeToString(&data);
 
TestStruct tSt2;
tSt2.ParseFromString(data);
for(auto it = tSt2.data().cbegin(); it != tSt2.data().cend(); ++it)
{
    std::cout << it->first << " " << it->second << std::endl;
}
 
std::string strTest;
TextFormat::PrintToString(tSt2, &strTest);
std::cout << strTest << std::endl;
```

## 嵌套类

```protobuf
syntax = "proto3";

message PointLLHA {
  optional double longitude = 1
  optional double latitude = 2;
  optional double heading = 3;// 朝向
  optional double altitude = 4;// 高度
  optional double timestamp_sec = 5;// 时间戳
}

message VehicleHeartbeat {
  optional bool is_normal = 1;
  optional PointLLHA vehicle_pose = 2;
  optional double vehicle_speed = 3;
}

message VehicleRoutingInfo { 
  repeated PointLLHA way_points = 1; 
}


```

### 错误嵌套赋值

```protobuf
自己定义的复杂嵌套消息不能够通过简单的set_来赋值，可采取set_allocated和mutable_两种方式，但是二者的赋值方式是不同的。

使用set_allocated_，赋值的对象需要new出来，不能用局部的，因为这里用的的是对象的指针。当局部的对象被销毁后，就会报错。

PointLLHA point;
point.set_longitude(116.20);
point.set_latitude(39.56);
vehicle_heartbeat.set_allocated_vehicle_pose(&point);// 这里传入的是一个马上会被销毁的指针

```

### **set_allocated_**

```protobuf
PointLLHA *point = new PointLLHA;
point->set_longitude(116.20);
point->set_latitude(39.56);
vehicle_heartbeat.set_allocated_vehicle_pose(point);// 这里传入的是一个指针
```

### **使用mutable_**

```protobuf
使用mutable_，赋值时候，可以使用局部变量，因为在调用的时，内部做了new操作。

PointLLHA point;
point.set_longitude(116.20);
point.set_latitude(39.56);
vehicle_heartbeat.mutable_vehicle_pose()->CopyFrom(point);// 这里传入的是一个变量，mutable内部有一个new函数
```

### 重复消息内容的赋值 带有repeated

```protobuf
带有repeated字段的消息，通过add_依次赋值

// 第一个点
PointLLHA *way_point = vehicle_routing_info.add_way_points();
way_point->set_longitude(116.20);
way_point->set_latitude(39.56);

// 第二个点
PointLLHA *way_point = vehicle_routing_info.add_way_points();
way_point->set_longitude(116.21);
way_point->set_latitude(39.57);

```

