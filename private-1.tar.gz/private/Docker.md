

# Docker概述

## docker为什么出现

![image-20220408195656066](Docker.assets/image-20220408195656066.png)

![image-20220408200050976](Docker.assets/image-20220408200050976.png)

## Docker的历史

![image-20220408200748748](Docker.assets/image-20220408200748748.png)

![image-20220408200933069](Docker.assets/image-20220408200933069.png)

## Docker能干嘛

![image-20220408201218114](Docker.assets/image-20220408201218114.png)

![image-20220408201318384](Docker.assets/image-20220408201318384.png)

docker技术

![image-20220408201510527](Docker.assets/image-20220408201510527.png)

![image-20220408201649565](Docker.assets/image-20220408201649565.png)

![image-20220408202129586](Docker.assets/image-20220408202129586.png)

# Docker的基本组成

![image-20220408202608177](Docker.assets/image-20220408202608177.png)



![image-20220409103833416](Docker.assets/image-20220409103833416.png)

# 安装Docker

![image-20220409104114769](Docker.assets/image-20220409104114769.png)

![image-20220409104330758](Docker.assets/image-20220409104330758.png)

![image-20220409104602995](Docker.assets/image-20220409104602995.png)

![image-20220409104854549](Docker.assets/image-20220409104854549.png)

![image-20220409104959224](Docker.assets/image-20220409104959224.png)

## 阿里云加速

![image-20220409105312828](Docker.assets/image-20220409105312828.png)

![image-20220409105403080](Docker.assets/image-20220409105403080.png)

![image-20220409105432162](Docker.assets/image-20220409105432162.png)

## 回顾HELLO WORLD 运行流程

![image-20220409105709162](Docker.assets/image-20220409105709162.png)

## 底层原理

![image-20220409110056465](Docker.assets/image-20220409110056465.png)



![image-20220409110232259](Docker.assets/image-20220409110232259.png)

## Docker为什么比虚拟机快

![image-20220409110538326](Docker.assets/image-20220409110538326.png)

# Docker的常用命令

## 帮助命令

![image-20220409111655571](Docker.assets/image-20220409111655571.png)

## 镜像命令

![image-20220409111953817](Docker.assets/image-20220409111953817.png)

![image-20220409112449895](Docker.assets/image-20220409112449895.png)

![image-20220409113208618](Docker.assets/image-20220409113208618.png)

![image-20220409113301508](Docker.assets/image-20220409113301508.png)

![image-20220409113323880](Docker.assets/image-20220409113323880.png)

![image-20220409113456722](Docker.assets/image-20220409113456722.png)

## 容器命令

![image-20220409134513194](Docker.assets/image-20220409134513194.png)

![image-20220409134725256](Docker.assets/image-20220409134725256.png)

![image-20220409134925560](Docker.assets/image-20220409134925560.png)

![image-20220409135240720](Docker.assets/image-20220409135240720.png)

![image-20220409135312533](Docker.assets/image-20220409135312533.png)

## 常用其他命令

![image-20220409140105230](Docker.assets/image-20220409140105230.png)

![image-20220409140526933](Docker.assets/image-20220409140526933.png)

![image-20220409140925017](Docker.assets/image-20220409140925017.png)

![image-20220409141012453](Docker.assets/image-20220409141012453.png)

![image-20220409141430933](Docker.assets/image-20220409141430933.png)

![image-20220409141534881](Docker.assets/image-20220409141534881.png)

# 小结

![image-20220409141937423](Docker.assets/image-20220409141937423.png)

![image-20220409142005849](Docker.assets/image-20220409142005849.png)

![image-20220409142048697](Docker.assets/image-20220409142048697.png)

# 作业练习

Docker安装Nginx

![image-20220409143321080](Docker.assets/image-20220409143321080.png)

![image-20220409143410772](Docker.assets/image-20220409143410772.png)

端口暴露概念

![image-20220409143032240](Docker.assets/image-20220409143032240.png)

![image-20220409143639794](Docker.assets/image-20220409143639794.png)

![image-20220409144620578](Docker.assets/image-20220409144620578.png)

![image-20220409144705478](Docker.assets/image-20220409144705478.png)

![image-20220409144906805](Docker.assets/image-20220409144906805.png)

![image-20220409145446967](Docker.assets/image-20220409145446967.png)

# 可视化

![image-20220409154019605](Docker.assets/image-20220409154019605.png)

![image-20220409154042742](Docker.assets/image-20220409154042742.png)

# Docker镜像讲解

## 镜像是什么

![image-20220409154511526](Docker.assets/image-20220409154511526.png)

## Docker镜像加载原理

![image-20220409154648678](Docker.assets/image-20220409154648678.png)

![](Docker.assets/image-20220409154802246.png)

![image-20220409155110422](Docker.assets/image-20220409155110422.png)

​                                 **黑屏-----通过加载------开机     开机完就可以卸载掉，所以bootfs这一部分是公用的**

​                                 **开机之后，就是rootfs系统，就是Linux，所以启动之后，容器就是一个小的虚拟机容器**

![image-20220409154927054](Docker.assets/image-20220409154927054.png)

![image-20220409161503973](Docker.assets/image-20220409161503973.png)

## 分层理解

![image-20220409161730246](Docker.assets/image-20220409161730246.png)

![image-20220409161903406](Docker.assets/image-20220409161903406.png)

![image-20220409161923256](Docker.assets/image-20220409161923256.png)

![image-20220409162110443](Docker.assets/image-20220409162110443.png)

![image-20220409162227989](Docker.assets/image-20220409162227989.png)

![image-20220409162347863](Docker.assets/image-20220409162347863.png)

![image-20220409162558212](Docker.assets/image-20220409162558212.png)

之后再次打包，形成自己的镜像

如何形成自己的镜像？

## commit镜像

![image-20220409163031656](Docker.assets/image-20220409163031656.png)

![image-20220409163617724](Docker.assets/image-20220409163617724.png)

![image-20220409163919925](Docker.assets/image-20220409163919925.png)

# 容器数据卷

## 什么是容器数据卷

![image-20220409164602538](Docker.assets/image-20220409164602538.png)

![image-20220409164529752](Docker.assets/image-20220409164529752.png)

​                                                                **总结：是为了容器的持久化和同步操作，容器间也是可以数据共享的**

## 使用数据卷

![image-20220409165137838](Docker.assets/image-20220409165137838.png)

![image-20220409165310407](Docker.assets/image-20220409165310407.png)

![image-20220409165436199](Docker.assets/image-20220409165436199.png)

![image-20220409165526820](Docker.assets/image-20220409165526820.png)

## 实战：部署MySQL

![image-20220409165957947](Docker.assets/image-20220409165957947.png)

![image-20220409170025300](Docker.assets/image-20220409170025300.png)

## 具名和匿名挂载

![image-20220409191326186](Docker.assets/image-20220409191326186.png)

![image-20220409191726555](Docker.assets/image-20220409191726555.png)

![image-20220409192043468](Docker.assets/image-20220409192043468.png)

## 初始Dockerfile

![image-20220409192708350](Docker.assets/image-20220409192708350.png)

![image-20220409192729050](Docker.assets/image-20220409192729050.png)

![image-20220409193228588](Docker.assets/image-20220409193228588.png)

![image-20220409193405354](Docker.assets/image-20220409193405354.png)

![image-20220409193422151](Docker.assets/image-20220409193422151.png)

![image-20220409193554728](Docker.assets/image-20220409193554728.png)

## 数据卷容器

![image-20220409193821080](Docker.assets/image-20220409193821080.png)

![image-20220409194406152](Docker.assets/image-20220409194406152.png)

![image-20220409194326942](Docker.assets/image-20220409194326942.png)

![image-20220409194454281](Docker.assets/image-20220409194454281.png)

![image-20220409194722603](Docker.assets/image-20220409194722603.png)

![image-20220409194947656](Docker.assets/image-20220409194947656.png)

![image-20220409195059611](Docker.assets/image-20220409195059611.png)

# DockerFile

## DockerFile介绍

![image-20220409195315723](Docker.assets/image-20220409195315723.png)

![image-20220409195457545](Docker.assets/image-20220409195457545.png)

## DockerFile构建过程

![image-20220409213511162](Docker.assets/image-20220409213511162.png)

![image-20220409213736442](Docker.assets/image-20220409213736442.png)

## DockerFile的指令

![image-20220409214416680](Docker.assets/image-20220409214416680.png)

![image-20220409214432088](Docker.assets/image-20220409214432088.png)

## 实战测试

![image-20220409214634104](Docker.assets/image-20220409214634104.png)

![image-20220409215204152](Docker.assets/image-20220409215204152.png)

![image-20220409215510461](Docker.assets/image-20220409215510461.png)

![image-20220409215548202](Docker.assets/image-20220409215548202.png)

![image-20220409215627383](Docker.assets/image-20220409215627383.png)

### cmd和ENTRYPOINT区别

![image-20220409215942157](Docker.assets/image-20220409215942157.png)

![image-20220409220145035](Docker.assets/image-20220409220145035.png)

![image-20220409220314235](Docker.assets/image-20220409220314235.png)

![image-20220409220356168](Docker.assets/image-20220409220356168.png)

![image-20220409220436329](Docker.assets/image-20220409220436329.png)

### 实战：Tomcat镜像

![image-20220409221646601](Docker.assets/image-20220409221646601.png)

![image-20220409221652219](Docker.assets/image-20220409221652219.png)

![image-20220410111537902](Docker.assets/image-20220410111537902.png)

## 发布自己的镜像

![image-20220410112946671](Docker.assets/image-20220410112946671.png)

![image-20220410112922514](Docker.assets/image-20220410112922514.png)

![image-20220410113229872](Docker.assets/image-20220410113229872.png)

![image-20220410113418464](Docker.assets/image-20220410113418464.png)

![image-20220410113508050](Docker.assets/image-20220410113508050.png)

## 小结

![image-20220410113941726](Docker.assets/image-20220410113941726.png)

![image-20220410113946004](Docker.assets/image-20220410113946004.png)

![image-20220410113949919](Docker.assets/image-20220410113949919.png)

# Docker网络

## 理解Docker0

![image-20220410114456558](Docker.assets/image-20220410114456558.png)

![image-20220410114612812](Docker.assets/image-20220410114612812.png)

![image-20220410114941921](Docker.assets/image-20220410114941921.png)

![image-20220410115122510](Docker.assets/image-20220410115122510.png)

![image-20220410115334851](Docker.assets/image-20220410115334851.png)

![image-20220410115402926](Docker.assets/image-20220410115402926.png)

![image-20220410115609679](Docker.assets/image-20220410115609679.png)

![image-20220410131152560](Docker.assets/image-20220410131152560.png)

![image-20220410132543536](Docker.assets/image-20220410132543536.png)

![image-20220410132929263](Docker.assets/image-20220410132929263.png)

### 小结

![image-20220410133052498](Docker.assets/image-20220410133052498.png)

![image-20220410133400348](Docker.assets/image-20220410133400348.png)

## --link

![image-20220410134201967](Docker.assets/image-20220410134201967.png)

![image-20220410134255167](Docker.assets/image-20220410134255167.png)

![image-20220410134515603](Docker.assets/image-20220410134515603.png)

![image-20220410135003887](Docker.assets/image-20220410135003887.png)

## 自定义网络

![image-20220410135127249](Docker.assets/image-20220410135127249.png)

![image-20220410140426785](Docker.assets/image-20220410140426785.png)

![image-20220410140842784](Docker.assets/image-20220410140842784.png)

![image-20220410141026675](Docker.assets/image-20220410141026675.png)

![image-20220410141054275](Docker.assets/image-20220410141054275.png)

![image-20220410141416560](Docker.assets/image-20220410141416560.png)

![image-20220410141422434](Docker.assets/image-20220410141422434.png)

![image-20220410141322451](Docker.assets/image-20220410141322451.png)

![image-20220410141558801](Docker.assets/image-20220410141558801.png)

![image-20220410141603182](Docker.assets/image-20220410141603182.png)

## 网络连通

![image-20220410141939839](Docker.assets/image-20220410141939839.png)

![image-20220410142008593](Docker.assets/image-20220410142008593.png)

![image-20220410142154959](Docker.assets/image-20220410142154959.png)

![image-20220410142457526](Docker.assets/image-20220410142457526.png)

![image-20220410142617425](Docker.assets/image-20220410142617425.png)

![image-20220410142716413](Docker.assets/image-20220410142716413.png)

# Docker常见问题

## docker镜像默认下载路径迁移，及默认保存位置迁移

- **出现问题**： linux系统盘空间太小了，如果将docker装在系统盘下，很容易被占满，这个时候就需要将docker默认的下载及镜像保存的路径改到空间大的磁盘中。

- **解决方法**：

  1. 终端输入docker info

  2. 找到docker默认下载目录，如下图Docker Root Dir: /var/lib/docker

  3. 停止docker   

     ```
     sudo systemctl stop docker
     ```

  4. 修改docker配置文件

     - 首先查找docker配置文件位置： find / -name daemon.json

     - 修改配置文件 daemon.json

       ```
        {
         "registry-mirrors": [
           "https://uvq8ymnc.mirror.aliyuncs.com" 
         ],
         "data-root": "/disk3/docker"
       }
       ```

  5. 

     将步骤二中的docker目录“Docker Root Dir:/var/lib/docker”中的文件全部剪切到外接硬盘所建的目录中。

     ```
     命令：mv /var/lib/docker/* /disk3/docker/
     ```

  6. 重新启动docker

     ```
     sudo systemctl start docker
     ```

​		7.查看确认	

```
docker info
```



## Docker

./robotrain/drivers/livox_ros_driver/CATKIN_IGNORE



## docker进不去

可先查看docker 的log，看问题出在何处

![image-20220923182718385](Docker.assets/image-20220923182718385.png)

## 用户加入docker组

```
 1. 创建docker用户组
 sudo groupadd docker
 2. 应用用户加入docker用户组
  sudo usermod -aG docker ${USER}
 3.重启docker服务
  sudo systemctl restart docker
```

