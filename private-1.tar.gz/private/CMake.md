

# 杂记

## 中文文档

https://runebook.dev/zh/docs/cmake/-index-

## Modern CMake 网址

https://modern-cmake-cn.github.io/Modern-CMake-zh_CN/

## set  cache

https://www.cnblogs.com/Braveliu/p/15614013.html

- 定义缓存变量时，可以不加FORCE选项
- 修改缓存变量时，一定要加FORCE选项，否则修改无效
- Cache变量都会保存在CMakeCache.txt文件中
- 不论定义或修改缓存变量时，建议都加上FORCE选项。

## CMakeCache.txt文件

​	**CMake中的缓存变量都会保存在CMakeCache.txt文件中**

​	如若不保存，想作为全局变量根本没法实现

## list

https://www.jianshu.com/p/89fb01752d6f

对`列表`的操作分为`读取`、`查找`、`修改`、`排序`等4个大类，下面按照这四个大类逐一对列表的子命令进行介绍。

### 读取

1. **`LENGTH`**：子命令LENGTH用于读取列表长度

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (LENGTH list_test length)
message (">>> LENGTH: ${length}")

# 输出
>>> LENGTH: 4
```

2. **`GET`**：子命令GET用于读取列表中指定索引的的元素，可以指定多个索引。

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (GET list_test 0 1 -1 -2 list_new)
message (">>> GET: ${list_new}")

# 输出
>>> GET: a;b;d;c
```

3. **`JOIN`**：子命令JOIN用于将列表中的元素用连接字符串连接起来组成一个字符串，注意，此时返回的结果已经不是一个列表。

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (JOIN list_test -G- list_new)
message (">>> JOIN: ${list_new}")

# 输出
>>> JOIN: a-G-b-G-c-G-d
```

4. **`SUBLIST`**：子命令SUBLIST用于获取列表中的一部分（子列表）

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (SUBLIST list_test 1 2 list_new)
message (">>> SUBLIST: ${list_new}")
list (SUBLIST list_test 1 0 list_new)
message (">>> SUBLIST: ${list_new}")
list (SUBLIST list_test 1 -1 list_new)
message (">>> SUBLIST: ${list_new}")
list (SUBLIST list_test 1 8 list_new)
message (">>> SUBLIST: ${list_new}")

# 输出
>>> SUBLIST: b;c
>>> SUBLIST:
>>> SUBLIST: b;c;d
>>> SUBLIST: b;c;d
```

### 查找

1. **`FIND`**：子命令FIND用于查找列表是否存在指定的元素

   如果列表`<list>`中存在`<value>`，那么返回`<value>`在列表中的索引，如果未找到则返回-1。

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (FIND list_test d list_index)
message (">>> FIND 'd': ${list_index}")
list (FIND list_test e list_index)
message (">>> FIND 'e': ${list_index}")

# 输出
>>> FIND 'd': 3
>>> FIND 'e': -1
```

### 修改

1.  **`APPEND`**：子命令APPEND用于将元素追加到列表

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (APPEND list_test 1 2 3 4)
message (">>> APPEND: ${list_test}")

# 输出
>>> APPEND: a;b;c;d;1;2;3;4
```

2. **`FILTER`**：子命令FILTER用于根据正则表达式包含或排除列表中的元素

```
list (FILTER <list> <INCLUDE|EXCLUDE> REGEX <regular_expression>)
  根据模式的匹配结果，将元素添加（INCLUDE选项）到列表或者从列表中排除（EXCLUDE选项）。此命令会改变原来列表的值。模式REGEX表明会对列表进行正则表达式匹配。（从官方文档目前未找到其他模式）

# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d 1 2 3 4) # 创建列表变量"a;b;c;d;1;2;3;4"
message (">>> the LIST is: ${list_test}")
list (FILTER list_test INCLUDE REGEX [a-z])
message (">>> FILTER: ${list_test}")
list (FILTER list_test EXCLUDE REGEX [a-z])
message (">>> FILTER: ${list_test}")

# 输出
>>> the LIST is: a;b;c;d;1;2;3;4
>>> FILTER: a;b;c;d
>>> FILTER: 
```

3. **`INSERT`**：子命令INSERT用于在指定位置将元素（一个或多个）插入到列表中

```
list (INSERT <list> <element_index> <element> [<element> ...])
  <element_index>为列表指定的位置，如果元素的位置超出列表的范围，会报错。此命令会改变原来列表的值。

# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (INSERT list_test 0 8 8 8 8)
message (">>> INSERT: ${list_test}")
list (INSERT list_test -1 9 9 9 9)
message (">>> INSERT: ${list_test}")
list (LENGTH list_test lenght)
list (INSERT list_test ${length} 0)
message (">>> INSERT: ${list_test}")

# 输出
>>> INSERT: 8;8;8;8;a;b;c;d
>>> INSERT: 8;8;8;8;a;b;c;9;9;9;9;d
>>> INSERT: 8;8;8;8;a;b;c;9;9;9;9;d;0
```

4. **`POP_BACK`**：子命令POP_BACK用于将列表中最后元素移除

```
list (POP_FRONT <list> [<out-var>...])
  <out-var>如果未指定输出变量，则仅仅是将原列表的第一个元素移除。如果指定了输出变量，则会将第一个元素移入到该变量，并将元素从原列表中移除。如果指定了多个输出变量，则依次将原列的第一个元素移入到输出变量中，如果输出变量个数大于列表的长度，那么超出部分的输出变量未定义。

# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (POP_FRONT list_test)
message (">>> POP_FRONT: ${list_test}")
list (POP_FRONT list_test outvar1 outvar2 outvar3 outvar4)
message (">>> POP_FRONT: ${outvar1}、${outvar2}、${outvar3}、${outvar4}")

# 输出
>>> POP_FRONT: b;c;d
>>> POP_FRONT: b、c、d、
```

5. **`PREPEND`**：子命令PREPEND用于将元素插入到列表的0索引位置

```
list (PREPEND <list> [<element> ...])
  如果待插入的元素是多个，则相当于把多个元素整体“平移”到原列表0索引的位置。
  
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d) # 创建列表变量"a;b;c;d"
list (PREPEND list_test z)
message (">>> PREPEND: ${list_test}")
list (PREPEND list_test p q r s t)
message (">>> POP_FRONT: ${list_test}")

# 输出
>>> PREPEND: z;a;b;c;d
>>> PREPEND: p;q;r;s;t;z;a;b;c;d
```

6. **`REMOVE_ITEM`**：子命令REMOVE_ITEM用于将指定的元素从列表中移除

```
list (REMOVE_ITEM <list> <value> [<value> ...])
  注意：指定的是元素的值，当指定的值在列表中存在重复的时候，会删除所有重复的值。
  
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a a b c c d) # 创建列表变量"a;a;b;c;c;d"
list (REMOVE_ITEM list_test a)
message (">>> REMOVE_ITEM: ${list_test}")
list (REMOVE_ITEM list_test b e)
message (">>> REMOVE_ITEM: ${list_test}")

# 输出
>>> REMOVE_ITEM: b;c;c;d
>>> REMOVE_ITEM: c;c;d
```

7. **`REMOVE_AT`**：子命令REMOVE_AT用于将指定索引的元素从列表中移除

```
list (REMOVE_AT <list> <index> [<index> ...])
  注意：指定的是元素的索引，当指定的索引不存在的时候，会提示错误；如果指定的索引存在重复，则只会执行一次删除动作。

# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a b c d e f) # 创建列表变量"a;b;c;d;e;f"
list (REMOVE_AT list_test 0 -1)
message (">>> REMOVE_AT: ${list_test}")
list (REMOVE_AT list_test 1 1 1 1)
message (">>> REMOVE_AT: ${list_test}")

# 输出
>>> REMOVE_AT: b;c;d;e
>>> REMOVE_AT: b;d;e
```

8. **`REMOVE_DUPLICATES`**：子命令REMOVE_DUPLICATES用于移除列表中的重复元素

```
list (REMOVE_DUPLICATES <list>)
  如果没有重复元素，原列表不会做更改。如果原列表所有元素都是一样的，则会保留一个；如果有多个重复元素，则保留第一个。
  
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test a a a b b b c c c d d d) # 创建列表变量"a;a;a;b;b;b;c;c;c;d;d;d;"
list (REMOVE_DUPLICATES list_test)
message (">>> REMOVE_DUPLICATES: ${list_test}")
set (list_test a a a a) 
list (REMOVE_DUPLICATES list_test)
message (">>> REMOVE_DUPLICATES: ${list_test}")
set (list_test a b c a d a e a f)  # 多个元素重复，只保留第一个 
list (REMOVE_DUPLICATES list_test)
message (">>> REMOVE_DUPLICATES: ${list_test}")

# 输出
>>> REMOVE_DUPLICATES: a;b;c;d
>>> REMOVE_DUPLICATES: a
>>> REMOVE_DUPLICATES: a;b;c;d;e;f
```

### **排序**

1. **`REVERSE`**：子命令REVERSE用于将整个列表反转

```
# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test aa bb cc dd) 
message (">>> list: ${list_test}")
list (REVERSE list_test)
message (">>> REVERSE: ${list_test}")

# 输出
>>> list: aa;bb;cc;dd
>>> REVERSE: dd;cc;bb;aa
```

2. **`SORT`**：子命令SORT用于对列表进行排序

```
list (SORT <list> [COMPARE <compare>] [CASE <case>] [ORDER <order>])
  对列表进行排序。

COMPARE：指定排序方法。有如下几种值可选：1）STRING:按照字母顺序进行排序，为默认的排序方法；2）FILE_BASENAME：如果是一系列路径名，会使用basename进行排序；3）NATURAL：使用自然数顺序排序。
CASE：指明是否大小写敏感。有如下几种值可选：1）SENSITIVE:按照大小写敏感的方式进行排序，为默认值；2）INSENSITIVE：按照大小写不敏感方式进行排序。
ORDER：指明排序的顺序。有如下几种值可选：1）ASCENDING:按照升序排列，为默认值；2）DESCENDING：按照降序排列。

# CMakeLists.txt
cmake_minimum_required (VERSION 3.12.2)
project (list_cmd_test)
set (list_test 3 1 1.1 10.1 3.4 9)
list (SORT list_test) # 以字母顺序，按照大小写敏感方式，升序排列
message (">>> SORT STRING-SENSITIVE-ASCENDING: ${list_test}")
list (SORT list_test COMPARE NATURAL ORDER DESCENDING) # 以自然顺序，降序排列
message (">>> SORT STRING-SENSITIVE-DESCENDING: ${list_test}")

# 输出
>>> SORT STRING-SENSITIVE-ASCENDING: 1;1.1;10.1;3;3.4;9
>>> SORT STRING-SENSITIVE-DESCENDING: 10.1;9;3.4;3;1.1;1
```

## set_property

​	在给定范围内设置一个对象的属性

​	在开发过程碰到需要在上级目录中构建，而源代码又分别写在下级目录的情况，同时又要根据不同的情况选择性地添加不同的源代码进行编译，所以考虑将需要编译的源代码放到一个 cmake 列表中。但是 set() 对应生成的变量都是局部变量（即不同的目录下不共用），于是使用 set_property() 命令。

```cmake
set_property(<GLOBAL                      |
              DIRECTORY [<dir>]           |
              TARGET    [<target1> ...]   |
              SOURCE    [<src1> ...]
                        [DIRECTORY <dirs> ...]
                        [TARGET_DIRECTORY <targets> ...] |
              INSTALL   [<file1> ...]     |
              TEST      [<test1> ...]     |
              CACHE     [<entry1> ...]    >
             [APPEND] [APPEND_STRING]
             PROPERTY <name> [<value1> ...])
 
 # 其基本格式为：
 set_property(<Scope> [APPEND] [APPEND_STRING] PROPERTY <name> [value...])
 
 第一个参数必须是属性的范围(Scope)，后面 [APPEND | APPEND_STRING] 可选，表示属性是可扩展的列表。PROPERTY 是标识，后面接属性名称<name>，其值可选。
 
 
# 设置全局属性 SOURCE_LIST
set_property( GLOBAL APPEND PROPERTY SOURCE_LIST)

file(GLOB_RECURSE SRC_LIST "*.cpp" "*.c")    # 查找当前目录下所有 .cpp 和 .c 文件
set_property( GLOBAL APPEND PROPERTY SOURCE_LIST ${SRC_LIST})   # 将这些文件路径附加到 SOURCE_LIST 后面
```

![image-20230202121309029](CMake.assets/image-20230202121309029.png)

## find_program

   CMake中的命令find_program用于查找程序(program)，其格式如下：将创建一个由<VAR>命名的缓存条目即cache变量，将<VAR>的值存入CMakeCache.txt中;或如果指定了NO_CACHE，由<VAR>命名的普通变量来存储此命令的结果，这种情况下，<VAR>的值将不会存入CMakeCache.txt中。如果找到程序，则结果将存储在<VAR>中，除非清除<VAR>，否则不会重复搜索。如果没找到，结果将为<VAR>-NOTFOUND。

1. NAMES：为程序指定一个或多个可能的名字

```cmake
unset(var CACHE) # 清除变量,带有CACHE也从缓存文件CMakeCache.txt中清除,若不带CACHE则缓存文件CMakeCache.txt中仍然存在var的值
find_program(var NAMES cmake)
message("var: ${var}") # var: /usr/bin/cmake
 
unset(var CACHE)
find_program(var gcc) # 最简格式：find_program(<VAR> name),查找默认路径
message("var: ${var}") # var: /usr/bin/gcc
 
# 如果找到程序,则结果将存储在变量中,除非清除变量,否则不会重复搜索
find_program(var NAMES cmake) # 注意:未清除变量,不会重复搜索,最终结果是不对的,并没有查找cmake
message("var: ${var}") # var: /usr/bin/gcc
 
unset(var) # 若不带CACHE,则var是/usr/bin/gcc而不是/usr/bin/cmake
find_program(var NAMES cmake)
message("var: ${var}") # var: /usr/bin/gcc
 
unset(var CACHE)
find_program(var NAMES valgrind) # 如果没找到程序,结果将为<VAR>-NOTFOUND
message("var: ${var}") # var: var-NOTFOUND
if(${var} STREQUAL "var-NOTFOUND")
	message(WARNING "the specified program was not found")
endif()
if(NOT var) # 注意这里是var不是${var}
	message(WARNING "the specified program was not found")
endif()
 
unset(var) # 不带CACHE则缓存文件CMakeCache.txt中仍然存在var的值
```

2. HINTS, PATHS：指定除默认位置外还要搜索的目录

```cmake
# 手动将/usr/bin/cmake拷贝到/opt/cmake/目录下
unset(var CACHE)
find_program(var NAMES cmake PATHS /opt/cmake) # PATHS:先搜索系统路径,然后再搜索PATHS指定的路径
message("var: ${var}") # var: /usr/bin/cmake
 
unset(var CACHE)
find_program(var NAMES cmake HINTS /opt/cmake) # HINTS:先搜索HINTS指定的路径,然后再搜索系统路径
message("var: ${var}") # var: /opt/cmake/cmake
```

3. PATH_SUFFIXES：若在PATHS或HINTS指定的路径中没有找到，则会在PATHS/PATH_SUFFIXES或HINTS/PATH_SUFFIXES指定的路径中继续搜索。示例代码段如下：    

**目录递归搜索**

```cmake
unset(var CACHE)
find_program(var NAMES cmake PATHS /opt NO_DEFAULT_PATH) # 仅搜索:/opt/
message("var: ${var}") # var: var-NOTFOUND
 
unset(var CACHE)
find_program(var NAMES cmake PATHS /opt PATH_SUFFIXES cmake NO_DEFAULT_PATH) # 搜索:(1)/opt; (2)/opt/cmake/
message("var: ${var}") # var: /opt/cmake/cmake
```

4. DOC：指定由<VAR>命名的缓存条目的文档字符串，即在CMakeCache.txt文件中会增加对<VAR>的描述。

```cmake
unset(var CACHE)
find_program(var NAMES cmake DOC "cmake program") # CMakeCache.txt中会对var增加注释说明
message("var: ${var}") # var: /usr/bin/cmake

在没有添加DOC选项时，CMakeCache.txt中var内容为：
//Path to a program.
var:FILEPATH=/usr/bin/cmake

添加DOC选项后，CMakeCache.txt中var内容变为：
//cmake program
var:FILEPATH=/usr/bin/cmake
```

5. REQUIRED:3.18版本中引入。**如果未找到任何内容，则停止处理并触发错误消息**，否则下次使用相同的变量调用find_program时将再次尝试搜索

```cmake
unset(var CACHE)
find_program(var NAMES valgrind) # 找不到会继续后续的执行
message("var: ${var}") # var: var-NOTFOUND
 
unset(var CACHE)
find_program(var NAMES valgrind REQUIRED) # 将触发error,停止后续的执行:CMake Error at test_find_program.cmake:68 (find_program): Could not find var using the following names: valgrind
```

6. .NO_DEFAULT_PATH:如果指定了此选项，则不会向搜索中添加其它路径。**默认搜索路径将失效,只会搜索PATHS和HINTS指定的路径**

```cmake
# 手动将/usr/bin/cmake拷贝到/opt/cmake/目录下
unset(var CACHE)
find_program(var NAMES cmake PATHS /opt/cmake NO_DEFAULT_PATH) # 指定不使用默认路径,path最后带不带"/"均可
message("var: ${var}") # var: /opt/cmake/cmake
 
unset(var CACHE)
find_program(var NAMES cmake NO_DEFAULT_PATH)
message("var: ${var}") # var: var-NOTFOUND
 
unset(var CACHE)
find_program(var NAMES cmake)
message("var: ${var}") # var: /usr/bin/cmake
```

## find_package

引入外部依赖包

1. 通过Cmake内置模块引入依赖包

```cmake
cmake官方为我们预定义了许多寻找依赖包的Module，他们存储在path_to_your_cmake/share/cmake-<version>/Modules目录下。每个以Find<LibaryName>.cmake命名的文件都可以帮我们找到一个包。

官方已经定义好了FindCURL.cmake。所以我们在CMakeLists.txt中可以直接用find_pakcage进行引用

对于系统预定义的 Find<LibaryName>.cmake 模块，使用方法一般如下例所示。

find_package(CURL)
add_executable(curltest curltest.cc)
if(CURL_FOUND)
    target_include_directories(clib PRIVATE ${CURL_INCLUDE_DIR})
    target_link_libraries(curltest ${CURL_LIBRARY})
else(CURL_FOUND)
    message(FATAL_ERROR ”CURL library not found”)
endif(CURL_FOUND)
```

2. 通过find_package引入非官方的库（该方式只对支持cmake编译安装的库有效）

```
1.安装
# clone该项目
git clone https://github.com/google/glog.git 
# 切换到需要的版本 
cd glog
git checkout v0.40  

# 根据官网的指南进行安装
cmake -H. -Bbuild -G "Unix Makefiles"
cmake --build build
cmake --build build --target install


2.引入glog库
find_package(GLOG)
add_executable(glogtest glogtest.cc)
if(GLOG_FOUND)
    # 由于glog在连接时将头文件直接链接到了库里面，所以这里不用显示调用target_include_directories
    target_link_libraries(glogtest glog::glog)
else(GLOG_FOUND)
    message(FATAL_ERROR ”GLOG library not found”)
endif(GLOG_FOUND)
```

### Module模式与Config模式

find_package对我们来说是一个黑盒子，那么它是具体通过什么方式来查找到我们依赖的库文件的路径的呢。

find_package的两种模式，一种是Module模式，也就是我们引入curl库的方式。另一种叫做Config模式，也就是引入glog库的模式

- module

```
在Module模式中，cmake需要找到一个叫做Find<LibraryName>.cmake的文件。
这个文件负责找到库所在的路径，为我们的项目引入头文件路径和库文件路径。
cmake搜索这个文件的路径有两个，一个是上文提到的cmake安装目录下的share/cmake-<version>/Modules目录，另一个使我们指定的CMAKE_MODULE_PATH的所在目录。
```

- config

```
如果Module模式搜索失败，没有找到对应的Find<LibraryName>.cmake文件，则转入Config模式进行搜索。
它主要通过<LibraryName>Config.cmake or <lower-case-package-name>-config.cmake这两个文件来引入我们需要的库。
以我们刚刚安装的glog库为例，在我们安装之后，它在/usr/local/lib/cmake/glog/目录下生成了glog-config.cmake文件，而/usr/local/lib/cmake/<LibraryName>/正是find_package函数的搜索路径之一。
（find_package的搜索路径是一系列的集合，而且在linux，windows，mac上都会有所区别，需要的可以参考官方文档find_package）
```

## 编写自己的`Find<LibraryName>.cmake`模块

1. 新建一个`ModuleMode`的文件夹
2. 函数库以手工编写Makefile的方式进行安装，库文件安装在/usr/lib目录下，头文件放在/usr/include目录下。
3. 在`cmake`文件夹下新建一个FindAdd.cmake的文件。我们的目标是找到库的头文件所在目录和共享库文件的所在位置。

```cmake
# 在指定目录下寻找头文件和动态库文件的位置，可以指定多个目标路径
find_path(ADD_INCLUDE_DIR libadd.h /usr/include/ /usr/local/include ${CMAKE_SOURCE_DIR}/ModuleMode)
find_library(ADD_LIBRARY NAMES add PATHS /usr/lib/add /usr/local/lib/add ${CMAKE_SOURCE_DIR}/ModuleMode)

if (ADD_INCLUDE_DIR AND ADD_LIBRARY)
    set(ADD_FOUND TRUE)
endif (ADD_INCLUDE_DIR AND ADD_LIBRARY)
```

4. 在CMakeLists.txt中添加

```cmake
# 将项目目录下的cmake文件夹加入到CMAKE_MODULE_PATH中，让find_pakcage能够找到我们自定义的函数库
set(CMAKE_MODULE_PATH "${CMAKE_SOURCE_DIR}/cmake;${CMAKE_MODULE_PATH}")
add_executable(addtest addtest.cc)
find_package(ADD)
if(ADD_FOUND)
    target_include_directories(addtest PRIVATE ${ADD_INCLUDE_DIR})
    target_link_libraries(addtest ${ADD_LIBRARY})
else(ADD_FOUND)
    message(FATAL_ERROR "ADD library not found")
endif(ADD_FOUND)
```

## add_definitions

在编译源文件时增加-D定义标志。

**`-D`后面的参数就是控制程序流向**

在更改别人代码做实验时使用，既不对其源码进行破坏，又可以添加自己的功能。之前都是在程序中进行#define，有了这个后可以直接在编译的时候进行选择。具体的，在工程CMakeLists.txt 中，使用add_definitions()函数控制代码的开启和关闭：

```cmake
add_definitions(-DFOO -DBAR ...)
在编译器命令行中添加当前目录中的目标的定义,不管是在调用此命令之前还是之后添加的,以及之后添加的子目录中的目标的定义。这个命令可以用来添加任何标志,但它的目的是添加预处理器定义。

option(TEST_DEBUG "option for debug" OFF)
if (TEST_DEBUG) 
	add_definitions(-DTEST_DEBUG)
endif(TEST_DEBUG)

运行构建项目的时候可以添加参数控制宏的开启和关闭．
 cmake -DTEST_DEBUG=1 .. #打开
 cmake -DTEST_DEBUG=0 .. #关闭

在源码中就可以使用：
#ifdef TEST_DEBUG
...
...
#else 
...
#endif
```



# 语法特性

**基本语法格式：指令(参数 1 参数 2…)**

- 参数使用**括弧**括起
- 参数之间使用**空格**或**分号**分开

**指令是大小写无关的，参数和变量是大小写相关的**

# 重要指令

## cmake_minimum_required

**cmake_minimum_required** **- 指定CMake的最小版本要求**

```
1	#CMake最小版本要求为2.8.3
2	cmake_minimum_required(VERSION 2.8.3)
```

- 语法：**cmake_minimum_required(VERSION versionNumber [FATAL_ERROR])**

## project

**project** **- 定义工程名称，并可指定工程支持的语言** 

```
1	# 指定工程名为HELLOWORLD
2	project(HELLOWORLD)
```

- 语法：**project(projectname [CXX] [C] [Java])**

## set

**set** **- 显式的定义变量** 

```
1	# 定义SRC变量，其值为main.cpp hello.cpp
2	set(SRC sayhello.cpp hello.cpp)
```

- 语法：**set(VAR [VALUE] [CACHE TYPE DOCSTRING [FORCE]])**

## include_directories

**include_directories - 向工程添加多个特定的头文件搜索路径**  --->相当于指定g++编译器的-I参数

```
1	# 将/usr/include/myincludefolder 和 ./include 添加到头文件搜索路径
2	include_directories(/usr/include/myincludefolder ./include)
```

- 语法：**include_directories([AFTER|BEFORE] [SYSTEM] dir1 dir2 …)**

## link_directories

**link_directories** **- 向工程添加多个特定的库文件搜索路径**  --->相当于指定g++编译器的-L参数

```
1	# 将/usr/lib/mylibfolder 和 ./lib 添加到库文件搜索路径
2	link_directories(/usr/lib/mylibfolder ./lib)
```

- 语法：link_directories(dir1 dir2 …) 

## add_library

**add_library** **- 生成库文件**

```
1	# 通过变量 SRC 生成 libhello.so 共享库
2	add_library(hello SHARED ${SRC})
```

- 语法：**add_library(libname [SHARED|STATIC|MODULE] [EXCLUDE_FROM_ALL] source1 source2 … sourceN)**

## add_compile_options

**add_compile_options** - 添加编译参数

```
1	# 添加编译参数 -Wall -std=c++11
2	add_compile_options(-Wall -std=c++11 -O2)
```

- 语法：**add_compile_options(**

## add_executable

**add_executable** **- 生成可执行文件**

```
1	# 编译main.cpp生成可执行文件main
2	add_executable(main main.cpp)
```

- 语法：**add_library(exename source1 source2 … sourceN)**

## target_link_libraries

**target_link_libraries** - 为 target 添加需要链接的共享库  --->相同于指定g++编译器-l参数

```
1	# 将hello动态库文件链接到可执行文件main
2	target_link_libraries(main hello)
```

- 语法：**target_link_libraries(target library1library2…)**

## target_include_directories

该命令可以指定目标（exe或者so文件）需要包含的头文件路径。

命名的<目标>必须是由add_executable()或add_library()之类的命令创建的，并且不能是ALIAS目标。通过显式地使用AFTER或BEFORE，就可以在附加和预挂之间进行选择，而不是依赖默认值。

- 将${OpenCV_Include_dir}头文件库路径**只**添加到了myLib项目

```
project(myLib)
target_include_directories（myLib PRIVATE ${OpenCV_Include_dir}）
```

```
INTERFACE：target对应的头文件使用
PRIVATE：target对应的源文件使用
PUBLIC：target对应的头文件、源文件都使用
```

注：如果有不同目录相同名称的头文件会产生影响，所以这里建议针对特定的target进行添加头文件的操作，不要使用include_directories

**2、差别：**

```
include_directories：
 当前`CMakeList.txt`中的所有目标以及所有在其调用点之后添加的子目录中的所有目标将具有此头文件搜索路径。

target_include_directories：
 指定目标包含的头文件路径
```

##  add_subdirectory

**add_subdirectory - 向当前工程添加存放源文件的子目录，并可以指定中间二进制和目标二进制存放的位置**

```
1	# 添加src子目录，src中需有一个CMakeLists.txt
2	add_subdirectory(src)
```

- 语法：**add_subdirectory(source_dir [binary_dir] [EXCLUDE_FROM_ALL])**

## aux_source_directory

**aux_source_directory - 发现一个目录下所有的源代码文件并将列表存储在一个变量中，这个指令临时被用来自动构建源文件列表**

```
1	# 定义SRC变量，其值为当前目录下所有的源代码文件
2	aux_source_directory(. SRC)
3	# 编译SRC变量所代表的源代码文件，生成main可执行文件
4	add_executable(main ${SRC})
```

- 语法：**aux_source_directory(dir VARIABLE)**

## install

### 目标文件安装

![image-20220905161048562](CMake.assets/image-20220905161048562.png)

![2022-07-18 11-16-05屏幕截图](CMake.assets/2022-07-18 11-16-05屏幕截图.png)

```
INSTALL(TARGETS myrun mylib mystaticlib
       RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
       LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
       ARCHIVE DESTINATION ${CMAKE_INSTALL_LIBDIR}
)
```

注：可执行二进制`myrun`安装到`${CMAKE_INSTALL_BINDIR}`目录，动态库`libmylib.so`安装到`${CMAKE_INSTALL_LIBDIR}`目录，静态库`libmystaticlib.a`安装到`${CMAKE_INSTALL_LIBDIR}`目录。

#### 安装include文件

```
file(GLOB_RECURSE APRILTAGS_HEADERS "src/*.h")
install(FILES ${APRILTAGS_HEADERS} DESTINATION ${CMAKE_INSTALL_PREFIX}/include)
```

# 其余指令

## function

```
function(<name>[arg1 [arg2 [arg3 ...]]])
    COMMAND1(ARGS ...)
    COMMAND2(ARGS ...)
    ...

endfunction(<name>)
```

定义一个函数名为<name>，参数名为arg1 arg2 arg3(…)。 函数体内的命令直到函数被调用的时候才会去执行。其中ARGC变量表示传递给函数的参数个数。 ARGV0, ARGV1, ARGV2代表传递给函数的实际参数。 ARGN代表超出最后一个预期参数的参数列表，例如，函数原型声明时，只接受一个参数，那么调用函数时传递给函数的参数列表中，从第二个参数（如果有的话）开始就会保存到ARGN。

```
cmake_minimum_required(VERSION 2.8)

project(ArgumentExpansion)

function (argument_tester arg)
    message(STATUS "ARGN: ${ARGN}")
    message(STATUS "ARGC: ${ARGC}")
    message(STATUS "ARGV: ${ARGV}")
    message(STATUS "ARGV0: ${ARGV0}")

    list(LENGTH ARGV  argv_len)
    message(STATUS "length of ARGV: ${argv_len}")
    set(i 0)
    while( i LESS ${argv_len})
         list(GET ARGV ${i} argv_value)
         message(STATUS "argv${i}: ${argv_value}")

         math(EXPR i "${i} + 1")
    endwhile()
endfunction ()

argument_tester(arg0 arg1 arg2 arg3)
```

```
运行结果：
-- ARGN: arg1;arg2;arg3
-- ARGC: 4
-- ARGV: arg0;arg1;arg2;arg3
-- ARGV0: arg0
-- ARGV1: arg1
-- length of ARGV: 4
-- argv0: arg0
-- argv1: arg1
-- argv2: arg2
-- argv3: arg3

```

## if和else

1. 基本语法

```
if(<condition>)
  <commands>
elseif(<condition>) # optional block, can be repeated
  <commands>
else()              # optional block
  <commands>
endif()
```

- 逻辑运算

```
# 取反运算
if(NOT <condition>)
# 与运算
if(<cond1> AND <cond2>)
# 或运算
if(<cond1> OR <cond2>)
```

- 特殊语句

```
if(COMMAND command-name)
如果给定名称是可以调用的命令，宏或函数，则为true。

if(POLICY policy-id)
如果给定名称是现有策略（格式为CMP<NNNN>），则为True 。

if(TARGET target-name)
如果给定名称是通过调用调用创建的现有逻辑目标名称，则为True。 add_executable()， add_library()， 要么 add_custom_target() 已经被调用的命令（在任何目录中）。

if(TEST test-name)
如果给定名称是由测试人员创建的现有测试名称，则为True add_test() 命令。

if(EXISTS path-to-file-or-directory)
如果指定的文件或目录存在，则为True。仅针对完整路径定义行为。解析符号链接，即，如果命名的文件或目录是符号链接，则如果符号链接的目标存在，则返回true。

if(file1 IS_NEWER_THAN file2)
如果file1是更新版本file2或两个文件之一不存在，则为true 。仅针对完整路径定义行为。如果文件时间戳完全相同，则IS_NEWER_THAN比较将返回true，这样，在出现平局的情况下将发生任何相关的生成操作。这包括为file1和file2传递相同文件名的情况。

if(IS_DIRECTORY path-to-directory)
如果给定名称是目录，则为True。仅针对完整路径定义行为。

if(IS_SYMLINK file-name)
如果给定名称是符号链接，则为True。仅针对完整路径定义行为。

if(IS_ABSOLUTE path)
如果给定路径是绝对路径，则为True。

if(<variable|string> MATCHES regex)
如果给定的字符串或变量的值与给定的常规条件匹配，则为true。有关正则表达式格式，请参见正则表达式规范。 ()组被捕获在CMAKE_MATCH_<n> 变量。

if(<variable|string> LESS <variable|string>)
如果给定的字符串或变量的值是有效数字且小于右边的数字，则为true。

if(<variable|string> GREATER <variable|string>)
如果给定的字符串或变量的值是有效数字并且大于右侧的数字，则为true。

if(<variable|string> EQUAL <variable|string>)
如果给定的字符串或变量的值是有效数字并且等于右侧的数字，则为true。

if(<variable|string> LESS_EQUAL <variable|string>)
如果给定的字符串或变量的值是有效数字且小于或等于右侧的数字，则为true。

if(<variable|string> GREATER_EQUAL <variable|string>)
如果给定的字符串或变量的值是有效数字并且大于或等于右侧的数字，则为true。

if(<variable|string> STRLESS <variable|string>)
如果给定的字符串或变量的值在字典上小于右侧的字符串或变量，则为true。

if(<variable|string> STRGREATER <variable|string>)
如果给定的字符串或变量的值在字典上大于右侧的字符串或变量，则为true。

if(<variable|string> STREQUAL <variable|string>)
如果给定的字符串或变量的值在字典上等于右侧的字符串或变量，则为true。

if(<variable|string> STRLESS_EQUAL <variable|string>)
如果给定的字符串或变量的值在字典上小于或等于右侧的字符串或变量，则为true。

if(<variable|string> STRGREATER_EQUAL <variable|string>)
如果给定的字符串或变量的值在字典上大于或等于右侧的字符串或变量，则为true。

if(<variable|string> VERSION_LESS <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_GREATER <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_EQUAL <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_LESS_EQUAL <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_GREATER_EQUAL <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> IN_LIST <variable>)
如果给定元素包含在命名列表变量中，则为true。

if(DEFINED <name>|CACHE{<name>}|ENV{<name>})
如果<name>定义了具有给定的变量，缓存变量或环境变量，则为true 。变量的值无关紧要。请注意，宏参数不是变量。

if((condition) AND (condition OR (condition)))
首先评估括号内的条件，然后像前面的示例一样评估其余条件。如果有嵌套的括号，则将最里面的括号作为包含它们的条件的一部分进行评估。
```



# CMake常用变量

## CMAKE_C_FLAGS

**CMAKE_C_FLAGS  gcc编译选项**

## CMAKE_CXX_FLAGS

**CMAKE_CXX_FLAGS  g++编译选项**

```
1	# 在CMAKE_CXX_FLAGS编译选项后追加-std=c++11
2	set( CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -std=c++11")
```

## CMAKE_BUILD_TYPE

**CMAKE_BUILD_TYPE  编译类型(Debug, Release)**

```
1	# 设定编译类型为debug，调试时需要选择debug
2	set(CMAKE_BUILD_TYPE Debug) 
3	# 设定编译类型为release，发布时需要选择release
4	set(CMAKE_BUILD_TYPE Release) 
```

## CMAKE_CURRENT_SOURCE_DIR

```
当前正在处理的源目录的路径
```

## CMAKE_SOURCE_DIR

```
最外层CMakeLists.txt所在目录
```

## CMAKE_C_COMPILER_LAUNCHER

```
指定一个以分号分隔的列表，其中包含编译器启动工具的命令行。 Makefile 生成器和 Ninja 生成器将运行此工具并将编译器及其参数传递给该工具。一些示例工具是 distcc 和 ccache。

如果路径中有CCache，使用"ccache g++“进行编译，否则使用g++
```

## CMAKE_PREFIX_PATH

```
以分号分隔的目录列表，指定要由 find_package()、find_program()、find_library()、find_file() 和 find_path() 命令搜索的安装前缀。每个命令都将添加其自己的文档中指定的适当子目录（如 bin、lib 或 include）。
默认情况下这是空的。它旨在由项目设置。
```



# cmak使用

## 1、CMakeLists.txt的创建

会自动创建两个变量，PROJECT_SOURCE_DIR和PROJECT_NAME

${PROJECT_SOURCE_DIR}：为包含PROJECT()的最近一个CMakeLists.txt文件所在的文件夹。

CMAKE_CURRENT_SOURCE_DIR:这是当前处理的CMakeLists.txt所在的目录

${PROJECT_NAME}：本CMakeLists.txt的project名称

1. 在需要进行编译的文件夹内编写`CMakeLists.txt`，即含有`.cpp/.c/.cc`的文件夹内：

## 2、二进制目录和源目录

<img src="CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70.png" alt="img" style="zoom:50%;" />

![img](/home/cargo/Desktop/CMake.assets/20210415232748255.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587316250624.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587316332846.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587316493588.png" alt="img" style="zoom:50%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873168935310.png" alt="img" style="zoom:50%;" />

## 3、message-输出自定义信息

```
1）CMake 的命令行工具会在 'stdout' 上显示 'STATUS' 消息，在 stderr 上显示'其他所有'消息
 
2）CMake '警告和错误消息'的文本显示使用的是一种'简单的标记语言';文本'没有缩进',超过长度的行会'回卷'，段落之间以'新行'做为'分隔符'
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873238470316.png" alt="img" style="zoom:40%;" />

```
+++++++++'消息不同级别的行为'+++++++++
 
 (无) = '重要'消息；
 STATUS = '非重要'消息；-->'常用'
 WARNING = CMake '警告', 会继续执行；
 AUTHOR_WARNING = CMake 警告 (dev), 会'继续'执行；
 SEND_ERROR = CMake 错误, '继续执行'，但是会'跳过生成的步骤'；-->'常用'
 FATAL_ERROR = CMake 错误, '终止所有'处理过程； -->'常用'
```

### message无参和STATUS级别的用法

![img](/home/cargo/Desktop/CMake.assets/20210414231120755.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873269333919.png" alt="img" style="zoom: 80%;" />

### 测试SEND_ERROR

![img](/home/cargo/Desktop/CMake.assets/20210414233004965.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873276246622.png" alt="img" style="zoom:80%;" />

### 测试FATAL_ERROR

![img](/home/cargo/Desktop/CMake.assets/20210414235051873.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873302972325.png" alt="img" style="zoom:85%;" />



## 4、构建静态库和动态库

- 基本语法

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873184327512.png" alt="img" style="zoom: 40%;" />

- 编辑CMakeLists.txt文件

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873215863414.png)

## 5、Cmake添加工程子目录

- ADD_SUBDIRECTORY语法

应用场景：  一般情况下,我们的项目'各个子项目'都在一个'总的项目根'目录下,但有的时候,我们需要使'用外部的文件夹'

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873319604827.png" alt="img" style="zoom:45%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873329444529.png" alt="img" style="zoom:45%;" />

- 示例

![img](/home/cargo/Desktop/CMake.assets/20210417095354195.png)

​				1.  编写SubDirectory项目的CMakeLists.txt文件

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873344904932.png" alt="img" style="zoom:80%;" />

​			2.编写src目录的CMakeLists.txt文件

![img](/home/cargo/Desktop/CMake.assets/20210417102948151.png)

```
细节： 父项目'SubDIrectory'根据自身的CMakesFiles.txt文件中的'add_subdirectory'指令,也会对子项目'src'进行'cmake3'

验证： cmkae3 .. 之后,子目录也声称了'Makefile'目录
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873370379135.png" alt="img" style="zoom:80%;" />

## 6、Cmake指定目标保存文件

核心差异性： 'add_subdirectory'除了保存'最终可执行文件',还会保存'编译生成的中间件'

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873412632837.png" alt="img" style="zoom:50%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873416176939.png" alt="img" style="zoom:50%;" />

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873423406841.png)

详细讲解：https://blog.csdn.net/wzj_110/article/details/115792879?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165873126616781790781827%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fblog.%2522%257D&request_id=165873126616781790781827&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~first_rank_ecpm_v1~times_rank-21-115792879-null-null.185

## 7、Cmake定义安装

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873461901843.png" alt="img" style="zoom:40%;" />

- 二进制安装规则

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873466477745.png" alt="img" style="zoom:40%;" />

### 二进制目标文件

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873484097547.png" alt="img" style="zoom:40%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873490496049.png" alt="img" style="zoom:40%;" />

#### 默认安装路径

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873494961151.png)

### 普通文件安装

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70.png" alt="img" style="zoom: 40%;" />

### 非目标可执行程序

备注： 一般是'sh'、'python'脚本

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587352267362.png" alt="img" style="zoom:40%;" />

### 目录的安装

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587352507334.png" alt="img" style="zoom:40%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587352654456.png" alt="img" style="zoom:40%;" />

## 8、Cmake设置生成库的属性

- 设置目标的属性

```
set_property(<GLOBAL                           |
             DIRECTORY [dir]                   |
             TARGET    [target1 [target2 ...]] |
             SOURCE    [src1 [src2 ...]]       |
             TEST      [test1 [test2 ...]]     |
             CACHE     [entry1 [entry2 ...]]>
             [APPEND][APPEND_STRING]
             PROPERTY <name>[value1 [value2 ...]])
```

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587356973458.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873575314010.png" alt="img" style="zoom:40%;" />

- 获取属性值

```
get_property: '获取'一个属性值
 
get_property(<variable>
               <GLOBAL             |
                DIRECTORY [dir]    |
                TARGET    <target> |
                SOURCE    <source> |
                TEST      <test>   |
                CACHE     <entry>  |
                VARIABLE>
                PROPERTY <name>
                [SET | DEFINED |BRIEF_DOCS | FULL_DOCS])
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873586477012.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/20210418220549660.png)

- 示例

### 设置动态库与静态库重名

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873618845217.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873616785115.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873643964321.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873645414223.png)

### 设置动态库

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873638352919.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873668998025.png" alt="img" style="zoom:80%;" />

```
效果： 动态库带'有版本号',并且有两个'链接文件'
 
1）带有'VERSION'的库
 
2）带有'SOVERSION'的库
```

## 9、Cmake调用外部库

### target_link_libraries

```
target_link_libraries  -->指定'目标链接'的'库'
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873698804827.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/20210419214653924.png)

###  include_directories

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873704070230.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873707136632.png)

### link_directories

```
1）官网'不推荐'使用'link_directoris',而是'推荐'使用'find_package'和'find_library'寻找'共享库的绝对路径',再'传给'target_link_libraries'使用'
 
2）'link_directories'必须放在link_libraries'之前'
```

![img](/home/cargo/Desktop/CMake.assets/2021041922094192.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873718934535.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/20210419220416787.png)

## 10、Cmake查询主机系统的特定信息

```
cmake_host_system_information(RESULT '<variable>' QUERY '<key>...')
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873827662438.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873836420740.png)

## 11、Cmake设置版本最低要求

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873846930042.png" alt="img" style="zoom:40%;" />

## 12、Cmake策略管理

![img](/home/cargo/Desktop/CMake.assets/20210423220217861.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873878406145.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/20210423222653104.png)

![img](/home/cargo/Desktop/CMake.assets/20210423223555581.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873883190749.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873911041653.png" alt="img" style="zoom:40%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873912499455.png" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873914639957.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165873916228359.png)

![2022-07-25 16-58-33屏幕截图](/home/cargo/Desktop/CMake.assets/2022-07-25 16-58-33屏幕截图.png)

## 13、Cmake配置文件

<img src="https://img-blog.csdnimg.cn/20210424152752127.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70" alt="img" style="zoom:40%;" />

![img](/home/cargo/Desktop/CMake.assets/20210424172024252.png)

- input.h

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587410161526.png)

- CMakeLists.txt

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16587410643698.png)

### 不加指令

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874110977810.png)

### COPYONLY指令

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874118065412.png)

### ESACPE_QUOTES指令

- ```
  1）'input_esacpe_quotes.h'-->'使用了'-->'不会对双引号转义'
  ```

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874126166314.png)

### @ONLY

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874147743616.png)



### NEW_WLINE STYLE

```
++++++++++++'windows下编写的,需要在Linux运行,解决换行问题'++++++++++++

input_newline_style_dos.h

input_newline_style_unix.h

'等价效果'： dos2unix

:%s/\r//g
+++++++++++++'查看换行方式'+++++++++++++
cat -A
set list 
```

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874162653618.png)

## 14、Cmake函数

### 函数定义

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874182495820.png" alt="img" style="zoom:40%;" />

### 函数调用

```
备注： 函数调用形成'自己的风格',尽量'大写'
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874189430522.png" alt="img" style="zoom:40%;" />

### 变量作用域

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874221570024.png" alt="img" style="zoom:40%;" />

### 函数的入参

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874226471826.png" alt="img" style="zoom:40%;" />

### 用例测试

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874270044530.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165874268685728.png)

<img src="/home/cargo/Desktop/CMake.assets/20210424185356817.png" alt="img" style="zoom:50%;" />

### 总结

```
1）函数'内部'可以引用'函数外部'的变量

  条件： 变量要在'函数外'定义,并且先于'函数调用前'执行

  备注： 不指定'PARENT_SCOPE',函数内如果'没有定义同名'变量,则读取'函数外'的变量

  补充： 函数内如果'定义同名'变量,则'读取'的是函数内的变量

  特点： 可以读取变量、但是'不能修改'

2）函数内部'定义的变量(var1)'可以在'函数外部'被引用 -->'PARENT_SCOPE'声明作用域

3）关于'函数嵌套',参考下面的参考博客
```

# 15、Cmake条件判断指令

1. 基本语法

```
if(<condition>)
  <commands>
elseif(<condition>) # optional block, can be repeated
  <commands>
else()              # optional block
  <commands>
endif()
```

- 逻辑运算

```
# 取反运算
if(NOT <condition>)
# 与运算
if(<cond1> AND <cond2>)
# 或运算
if(<cond1> OR <cond2>)
```

- 特殊语句

```
if(COMMAND command-name)
如果给定名称是可以调用的命令，宏或函数，则为true。

if(POLICY policy-id)
如果给定名称是现有策略（格式为CMP<NNNN>），则为True 。

if(TARGET target-name)
如果给定名称是通过调用调用创建的现有逻辑目标名称，则为True。 add_executable()， add_library()， 要么 add_custom_target() 已经被调用的命令（在任何目录中）。

if(TEST test-name)
如果给定名称是由测试人员创建的现有测试名称，则为True add_test() 命令。

if(EXISTS path-to-file-or-directory)
如果指定的文件或目录存在，则为True。仅针对完整路径定义行为。解析符号链接，即，如果命名的文件或目录是符号链接，则如果符号链接的目标存在，则返回true。

if(file1 IS_NEWER_THAN file2)
如果file1是更新版本file2或两个文件之一不存在，则为true 。仅针对完整路径定义行为。如果文件时间戳完全相同，则IS_NEWER_THAN比较将返回true，这样，在出现平局的情况下将发生任何相关的生成操作。这包括为file1和file2传递相同文件名的情况。

if(IS_DIRECTORY path-to-directory)
如果给定名称是目录，则为True。仅针对完整路径定义行为。

if(IS_SYMLINK file-name)
如果给定名称是符号链接，则为True。仅针对完整路径定义行为。

if(IS_ABSOLUTE path)
如果给定路径是绝对路径，则为True。

if(<variable|string> MATCHES regex)
如果给定的字符串或变量的值与给定的常规条件匹配，则为true。有关正则表达式格式，请参见正则表达式规范。 ()组被捕获在CMAKE_MATCH_<n> 变量。

if(<variable|string> LESS <variable|string>)
如果给定的字符串或变量的值是有效数字且小于右边的数字，则为true。

if(<variable|string> GREATER <variable|string>)
如果给定的字符串或变量的值是有效数字并且大于右侧的数字，则为true。

if(<variable|string> EQUAL <variable|string>)
如果给定的字符串或变量的值是有效数字并且等于右侧的数字，则为true。

if(<variable|string> LESS_EQUAL <variable|string>)
如果给定的字符串或变量的值是有效数字且小于或等于右侧的数字，则为true。

if(<variable|string> GREATER_EQUAL <variable|string>)
如果给定的字符串或变量的值是有效数字并且大于或等于右侧的数字，则为true。

if(<variable|string> STRLESS <variable|string>)
如果给定的字符串或变量的值在字典上小于右侧的字符串或变量，则为true。

if(<variable|string> STRGREATER <variable|string>)
如果给定的字符串或变量的值在字典上大于右侧的字符串或变量，则为true。

if(<variable|string> STREQUAL <variable|string>)
如果给定的字符串或变量的值在字典上等于右侧的字符串或变量，则为true。

if(<variable|string> STRLESS_EQUAL <variable|string>)
如果给定的字符串或变量的值在字典上小于或等于右侧的字符串或变量，则为true。

if(<variable|string> STRGREATER_EQUAL <variable|string>)
如果给定的字符串或变量的值在字典上大于或等于右侧的字符串或变量，则为true。

if(<variable|string> VERSION_LESS <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_GREATER <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_EQUAL <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_LESS_EQUAL <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> VERSION_GREATER_EQUAL <variable|string>)
按组件的整数版本号比较（版本格式为 major[.minor[.patch[.tweak]]]，省略的组件视为零）。任何非整数版本组件或版本组件的非整数结尾部分均会在该点处有效截断字符串。

if(<variable|string> IN_LIST <variable>)
如果给定元素包含在命名列表变量中，则为true。

if(DEFINED <name>|CACHE{<name>}|ENV{<name>})
如果<name>定义了具有给定的变量，缓存变量或环境变量，则为true 。变量的值无关紧要。请注意，宏参数不是变量。

if((condition) AND (condition OR (condition)))
首先评估括号内的条件，然后像前面的示例一样评估其余条件。如果有嵌套的括号，则将最里面的括号作为包含它们的条件的一部分进行评估。
```

# 16、Cmake的宏macro

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-165875057374633.png" alt="img" style="zoom:40%;" />

# 17、Cmake外部项目的导入

```
语法： 'ExternalProject_Add'(<name> [<option>...])
```

```
灵感来源： 'CI构建'用在非'C/C++'的工程中,只做'集成',不做'编译'
 
注意选择'对应的版本'解读  -->这里选择'3.16、3.17'
 
应用场景： 工程需要'编译'第'三方'源码,但是'第三方'源码和'自研'源码'不在'同一目录下
```

# 18、Cmake之列表

```
业务'驱动'： 'list'的应用'场景'
```

## 定义

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70.png" alt="img" style="zoom:50%;" />

## 获取

```
1) '获取'列表的'长度'
2) '读取'列表的元素
3) '截取'列表获取'子列表'
```

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16600377840883.png" alt="img" style="zoom:50%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16600378148775.png" alt="img" style="zoom:50%;" />

### 示例

![image-20220809173802668](/home/cargo/Desktop/CMake.assets/image-20220809173802668.png)

## 搜索操作

###  FIND查找

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16600380122667.png" alt="img" style="zoom: 33%;" />

![image-20220809174051085](/home/cargo/Desktop/CMake.assets/image-20220809174051085.png)

### 修改列表

#### 增

​													<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-16600380781719.png" alt="img" style="zoom:33%;" />	

#### 删

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003840788011.png" alt="img" style="zoom: 40%;" />

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003848044713.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003849023815.png)

## 排序

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003857367517.png" alt="img" style="zoom:50%;" />

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003860303019.png" alt="img" style="zoom: 50%;" />

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003862895721.png)

# 19、Cmake把外部项目项目添加到当前项目中

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003902983925.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003906123427.png)

![img](/home/cargo/Desktop/CMake.assets/20210429110152196.png)

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003912080430.png)

<img src="/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166003912839732.png" alt="img" style="zoom:90%;" />

# 20、config、cmake、make区别

## cmake

![示意图 from (1)](/home/cargo/Desktop/CMake.assets/20160423124818030.png)

```
1）cmake就像'autotools'的配置步骤,它本身并'不执行构建',而是为'构建'生成'必需的文件(Makefile)'
 
2）调用'cmake'相当于'./configure步骤'
 
3）CMake有'--build'选项，但这个选项只是'调用底层构建系统',你'不能使用cmake'作为'独立'的构建工具
 
4）cmake是一个'跨平台'的安装(编译)工具,达到的效果-->"write once,use everywhere"
 
5）makefile都包含了'编译'、'安装'、'打包'过程
```

**本质：cmake生成Makefile文件**

## configure

```
1）检测平台'是否安装了'对应的工具
 
2）根据'系统平台特性',自动生成符合'该平台的'Makefile文件
 
 ./configure –help
 
./configure –prefix=/usr  --> 对'安装'进行'控制';'默认'是/usr/local/bin
 
3）configure(shell)脚本'不是' UNIX/Linux世界中的*规则*;大多数时候它由'autotools生成',有时是"手动"生成的,有时是由其它'工具|语言'生成的
 
4）本质上就是一个'shell脚本'
 
备注： mysql 从'5.5开始',源代码安装将'原来的configure'改为cmake
```

## make

```
1）make all：产生我们设定的目标，即此范例中的可执行文件
 
备注： 只打make也可以，此时会开始编译原始码，然后链接，并且产生可执行文件。
 
2）make clean：'清除'编译产生的可执行文件及目标文件(object file，*.o)-->make'报错'清理使用
 
3）make distclean：'除了'清除可执行文件和目标文件外,把configure所产生的'Makefile也清除掉'
 
4）make install：将程序'安装'至系统中;如果原始码'编译无误',且执行结果正确,便可以把程序'安装至系统预设'的可执行文件存放路径
 
备注： 如果用'bin_PROGRAMS宏'的话,程序会被安装至'/usr/local/bin'这个目录
 
说明： 需要有'root'权限
 
5）make dist：将程序和相关的档案'包装成一个压缩文件'以供发布
 
效果：执行完在'目录下'会产生一个以'PACKAGE-VERSION.tar.gz'为名称的文件
 
备注：PACKAGE和VERSION这两个变数是'根据configure.in文件'中AM_INIT_AUTOMAKE(PACKAGE，VERSION)的定义
 
6）make V=1
 
输出'详细'的编译过程
 
6）gcc'编译'的流程：'预处理' --> '编译' --> '汇编' --> '链接' --> '执行'
 
8）make test|check '预检查'
```

## 总结

```
1、cmake根据CMakeLists.txt文件生成makefile文件
2、make 调用makefile文件中用户指定的命令来进行编译和链接的
```



```
1.gcc是GNU Compiler Collection（就是GNU编译器套件），也可以简单认为是编译器，它可以编译很多种编程语言（括C、C++、Objective-C、Fortran、Java等等）。
 
2.当你的程序只有一个源文件时，直接就可以用gcc命令编译它。
 
3.但是当你的程序包含很多个源文件时，用gcc命令逐个去编译时，你就很容易混乱而且工作量大
 
4.所以出现了make工具
make工具可以看成是一个智能的批处理工具，它本身并没有编译和链接的功能，而是用类似于批处理的方式—通过调用makefile文件中用户指定的命令来进行编译和链接的。
 
5.makefile是什么？简单的说就像一首歌的乐谱，make工具就像指挥家，指挥家根据乐谱指挥整个乐团怎么样演奏，make工具就根据makefile中的命令进行编译和链接的。
 
6.makefile命令中就包含了调用gcc（也可以是别的编译器）去编译某个源文件的命令。
 
7.makefile在一些简单的工程完全可以人工手下，但是当工程非常大的时候，手写makefile也是非常麻烦的，如果换了个平台makefile又要重新修改。
 
8.这时候就出现了Cmake这个工具，cmake就可以更加简单的生成makefile文件给上面那个make用。当然cmake还有其他功能，就是可以跨平台生成对应平台能用的makefile，你不用再自己去修改了。
 
9.可是cmake根据什么生成makefile呢？它又要根据一个叫CMakeLists.txt文件（学名：组态档）去生成makefile。
 
10.到最后CMakeLists.txt文件谁写啊？亲，是你自己手写的。
 
11.当然如果你用IDE，类似VS这些一般它都能帮你弄好了，你只需要按一下那个三角形
```

# 21、find_package指令

```
FIND_PACKAGE 命令用于'搜索'并加载'外部工程',其'隐含的变量'用于'标识'是否'搜索'到所需的'package_name'
```

### Module模式

```
cmake3 --help-command find_package  -->'find_package'的帮助文档
 
注意： 'Module'模式中 'REQUIRED'、COMPONENTS、EXACT、'QUIET'字段的解读
 
备注： 'MODULE'强制使用'module'模式,也即'module'找不到,则'error报错'
```

```
REQUIRED:制定该属性，包没找到，会立刻停止构建，并给一个错误消息
COMPONENTS:查找到的包中一定要包含这些组件，任何一个找不到就算失败
QUIET：即使查找失败，也会静默，（前提是没有指定REQUIRED）
```

![img](/home/cargo/Desktop/CMake.assets/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d6al8xMTA=,size_16,color_FFFFFF,t_70-166004575714235.png)