中文简介：http://paul.pub/dds-and-fastrtps/

b站：https://fishros.com/#/fish_home

官方文档：https://fast-dds.docs.eprosima.com/en/latest/

# DDS背景介绍

## 背景

1、如今分布式系统变得越来越复杂

2、对网络通信技术要求在功能和性能层面越来越高

## 问题

![image-20220429115925985](DDS.assets/image-20220429115925985.png)

![image-20220429115838433](DDS.assets/image-20220429115838433.png)

![image-20220429120023824](DDS.assets/image-20220429120023824.png)

![image-20220429120124179](DDS.assets/image-20220429120124179.png)

## 概念

![image-20220429120423329](DDS.assets/image-20220429120423329.png)

![image-20220429120615936](DDS.assets/image-20220429120615936.png)

## GDS（又称Domain）

![image-20220429120830653](DDS.assets/image-20220429120830653.png)

![image-20220429121108131](DDS.assets/image-20220429121108131.png)

## Topic

![image-20220429121521296](DDS.assets/image-20220429121521296.png)

## DDS通信形式

![img](DDS.assets/70.jpeg)

![image-20220429121921491](DDS.assets/image-20220429121921491.png)

### 数据发送

![image-20220429122147698](DDS.assets/image-20220429122147698.png)

### 数据接收

![image-20220429122357970](DDS.assets/image-20220429122357970.png)

![image-20220429122451792](DDS.assets/image-20220429122451792.png)

## 服务质量QoS

![image-20220429123031186](DDS.assets/image-20220429123031186.png)

注：消费者自己设置的服务质量，就决定了京东去运输商品的方式，最终让消费者体验这样的服务

### QoS策略

![image-20220429123711743](DDS.assets/image-20220429123711743.png)

### 数据的可用性

![image-20220429124436097](DDS.assets/image-20220429124436097.png)

注：系统启动时，有些节点启动快，有些节点启动慢，先启动会先发数据，后启动，则没接收到数据，会丢失。

LIFESPAN：举例车速的瞬时值

HISTORY：举例速度的变化趋势，判断车是加速还是减速

### 数据交付

![image-20220429130032498](DDS.assets/image-20220429130032498.png)

注：如车的坐标轴X,Y，只有当X,Y都到达时，才接收数据，防止接收旧的坐标

​		data sample1，data sample2，若传输层用udp传输，这两个数据通过网络中不同路径传输会，不在同一时间到达，也可能

data sample2先到，data sample1后到，

注：因为传输层的协议是不可靠的，必然会丢包，使用可靠送达需要重传，后面的新数据则等待，相当于一条路的高速。

![image-20220429130946321](DDS.assets/image-20220429130946321.png)

### 数据时效性

![image-20220429131308675](DDS.assets/image-20220429131308675.png)

注：DDS没有任何策略去保障优先级，直接透明的去传送给传输层，通过TRA。。。设置优先级

### 资源

![image-20220429131629313](DDS.assets/image-20220429131629313.png)

### 配置

![image-20220429131908528](DDS.assets/image-20220429131908528.png)

## DDS与some/ip

![image-20220429132650498](DDS.assets/image-20220429132650498.png)

注：some/ip是客户端/服务器

## TSN

![image-20220429133229779](DDS.assets/image-20220429133229779.png)

# DDS实现方案

![image-20220429133540568](DDS.assets/image-20220429133540568.png)